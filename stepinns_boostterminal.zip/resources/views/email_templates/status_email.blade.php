<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
         <div>
            <h1>
               Next Layer Technology 
            </h1>
        </div>
        <div>
              <h2>{{$client_id}} – {{$client_name}}</h2>
        </div>
         <div>
              <h2>Your Boost registration has been {{$is_status}}</h2>
        </div>
        
    </body>
</html>
