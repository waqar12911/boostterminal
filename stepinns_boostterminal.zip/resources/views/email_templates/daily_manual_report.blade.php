<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
               <h1>Daily Transaction Report of date: {{$currentDate}}</h1>
                
        </div>
    </body>
</html>