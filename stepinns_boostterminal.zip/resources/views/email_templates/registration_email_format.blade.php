<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
         <div>
            <h1>
                Welcome Sovereign, to the Next Layer Boost Terminal.
            </h1>
            <h2>
                The fastest way to recharge your lightning line!
            </h2>
             <h2>
                Here is your new user information:
            </h2>
        </div>
        <div>
               <h3>Client ID:  {{$client_id}}</h2>
               <h3>Client Name:  {{$client_name}}</h2>
               <h3>Client email:  {{$email}}</h2>
               <h3>Client Status:  {{$is_active}}</h2>
                
        </div>
    </body>
</html>