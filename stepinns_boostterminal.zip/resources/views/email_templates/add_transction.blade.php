<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
         <div>
            <h1>
               Boost Individual Recharge Receipt
            </h1>
        </div>
              <h2>Status Complete</h2>
              <h3>Merchant Id: {{$merchantId}}</h3>
        <div>
              <h3>Charge Time:</h3>
              <span>{{$chargeTime}} 21-02-1996 - 08:57 AM</span>
        </div>
        
        <div>
              <h3>Ammount:</h3>
              <span>123{{$mountBTC}}BTC</span><br>
              <span>032154{{$amountUSD}}SD</span>
        </div>
    </body>
</html>
