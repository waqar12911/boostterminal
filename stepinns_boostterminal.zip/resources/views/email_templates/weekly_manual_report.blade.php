<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
            <h2>
                Next Layer Technology Boost Terminal
            </h2>
        </div>
        <div>
               <h1>Corporate Custom Transaction Report – {{$weekStart}} to {{$weekEnd}}</h1>
                
        </div>
    </body>
</html>
