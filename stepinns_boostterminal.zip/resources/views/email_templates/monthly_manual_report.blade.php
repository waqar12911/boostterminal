<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
               <h1>Monthly Transaction Report of month: {{$month}} and year: {{$year}}</h1>
                
        </div>
    </body>
</html>
