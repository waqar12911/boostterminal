<?php


set_include_path(get_include_path() . PATH_SEPARATOR . 'phpsec');
include('phpsec/Net/SSH2.php');
include('phpsec/File/ANSI.php');

if(isset($_GET['type']) && !empty($_GET['type'])){
    if(isset($_GET['host']) && !empty($_GET['host'])){
        if(isset($_GET['port']) && !empty($_GET['port'])){
            if(isset($_GET['username']) && !empty($_GET['username'])){
                if(isset($_GET['password']) && !empty($_GET['password'])){
                }else{
                    echo json_encode(array("code" =>"400", "message" => "Password Required"));
                    exit();

                }
                
            }else{
                echo json_encode(array("code" =>"400", "message" => "Username Required"));
                exit();

            }
            
        }else{
            return json_encode(array("code" =>"400", "message" => "Port Required"));
            exit();

        }
        
    }else{
        echo json_encode(array("code" =>"400", "message" => "Host Required"));
        exit();

    }
    
}else{
    echo json_encode(array("code" =>"400", "message" => "Type Required"));
    exit();
}
// $host = "98.226.215.246";
// $port = "41000";
// $username = "routing-node-1";
// $password = "bitcoin2020";
// $type = $_GET['type'];
$host = $_GET['host'];
$port = $_GET['port'];
$username = $_GET['username'];
$password = $_GET['password'];
$type = $_GET['type'];

if($type == 'start'){
    $ansi = new File_ANSI();
    $ssh = new Net_SSH2($host,$port);
    if (!$ssh->login($username,$password)) {
        echo json_encode(array("code" =>"400", "message" => "Login Error"));
    }
    $ssh->setTimeout(1);
    $ssh->read();
    $ssh->write("screen -r Thor\n");
    $ssh->setTimeout(1);
    $ansi->loadString($ssh->read());
    $output = htmlspecialchars_decode(strip_tags($ansi->getScreen()));
    if(strpos($output, 'There is no screen to be resumed matching') !== false) {
        $ssh->write("screen -S Thor\n");
        $ssh->setTimeout(1);
        $ssh->write("sudo killall /thor/THOR \n");
        $ssh->setTimeout(1);
        $ansi->loadString($ssh->read());
        $sec = htmlspecialchars_decode(strip_tags($ansi->getScreen()));
        if(strpos($sec, 'password for') !== false) {
            $ssh->write($password . "\n");  
            $ssh->setTimeout(1);
            $ansi->loadString($ssh->read());
            htmlspecialchars_decode(strip_tags($ansi->getScreen()));
        }
        $ssh->write("/thor/THOR \n");
        $ssh->setTimeout(1);
        $ansi->loadString($ssh->read());
        htmlspecialchars_decode(strip_tags($ansi->getScreen()));  
        $res = "Screen Created With Process";
    }
    else if(strpos($output, '##') !== false && strpos($output, 'Terminated') === false) {
        $res = "Already Running";
    }else{
        $ssh->write("sudo killall /thor/THOR \n");
        $ssh->setTimeout(1);
        $ansi->loadString($ssh->read());
        $sec = htmlspecialchars_decode(strip_tags($ansi->getScreen()));
        if(strpos($sec, 'password for') !== false) {
            $ssh->write($password . "\n");  
            $ssh->setTimeout(1);
            $ansi->loadString($ssh->read());
            htmlspecialchars_decode(strip_tags($ansi->getScreen()));
        }
        $ssh->write("/thor/THOR \n");
        $ssh->setTimeout(1);
        $ansi->loadString($ssh->read());
        htmlspecialchars_decode(strip_tags($ansi->getScreen()));
        $res = "Process Started";
    }
    $ssh->disconnect(); unset($ssh); 
    echo json_encode(array("code" =>"200", "message" => $res));
    exit();

}else{
    $ansi = new File_ANSI();
    $ssh = new Net_SSH2($host,$port);
    if (!$ssh->login($username,$password)) {
        echo json_encode(array("code" =>"400", "message" => "Login Error"));
    }
    $ssh->setTimeout(1);
    $ssh->read();
    $ssh->write("sudo killall /thor/THOR \n");
    $ssh->setTimeout(1);
    $ansi->loadString($ssh->read());
    $res = htmlspecialchars_decode(strip_tags($ansi->getScreen()));
    if(strpos($res, 'password for') !== false) {
        $ssh->write($password . "\n");  
        $ssh->setTimeout(1);
        $ansi->loadString($ssh->read());
        htmlspecialchars_decode(strip_tags($ansi->getScreen()));
    }
    $ssh->disconnect(); unset($ssh);
    echo json_encode(array("code" =>"200", "message" => "Sucessfully Stoped"));
    exit();

        
}

//Could not connect to bitcoind using bitcoin-cli. Is bitcoind running?

    
?>